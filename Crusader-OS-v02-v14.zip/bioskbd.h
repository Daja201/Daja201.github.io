#ifndef BIOSKBD_H
#define BIOSKBD_H
/* bios keyboard*/
char bios_getchar_echo(void);
#endif
