#ifndef DISKINFO_H
#define DISKINFO_H

#include <stdint.h>

void detect_disk(void);
void identify_disk(void);

#endif