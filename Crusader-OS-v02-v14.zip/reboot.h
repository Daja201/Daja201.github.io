#pragma once

__attribute__((noreturn))
void reboot_triple_fault(void);
